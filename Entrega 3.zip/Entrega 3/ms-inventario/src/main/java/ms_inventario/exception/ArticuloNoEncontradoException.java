package com.hospital_vm.cl.ms_inventario.exception;

public class ArticuloNoEncontradoException extends RuntimeException {
    public ArticuloNoEncontradoException(String message) {
        super(message);
    }
}