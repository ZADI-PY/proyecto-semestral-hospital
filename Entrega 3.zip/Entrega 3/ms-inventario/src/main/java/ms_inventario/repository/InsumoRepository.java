package com.hospital_vm.cl.ms_inventario.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;
import com.hospital_vm.cl.ms_inventario.model.entity.Articulo;

@Repository
public interface ArticuloRepository extends JpaRepository<Articulo, Integer> {
    List<Articulo> findByCategoria(String categoria);
    
    // Consulta para obtener los artículos que están por debajo o igual a su stock mínimo
    @Query("SELECT a FROM Articulo a WHERE a.stockDisponible <= a.stockMinimo")
    List<Articulo> findArticulosConBajoStock();
}