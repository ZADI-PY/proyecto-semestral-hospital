package com.hospital_vm.cl.ms_inventario.model.entity;

import java.time.LocalDate;
import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "articulos")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Articulo {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(nullable = false, length = 100)
    private String nombre;

    @Column(nullable = false, length = 50)
    private String categoria; // Ej: MEDICAMENTO, INSUMO_QUIRURGICO, EQUIPAMIENTO

    @Column(nullable = false)
    private Integer stockDisponible;

    @Column(nullable = false)
    private Integer stockMinimo; // Alerta para reabastecimiento

    @Column(name = "fecha_vencimiento")
    private LocalDate fechaVencimiento; // Útil para medicamentos

    @Column(length = 100)
    private String ubicacion; // Ej: Bodega Central, Farmacia
}