package com.hospital_vm.cl.ms_inventario.controller;

import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import com.hospital_vm.cl.ms_inventario.dto.request.ArticuloRequestDTO;
import com.hospital_vm.cl.ms_inventario.dto.response.ArticuloResponseDTO;
import com.hospital_vm.cl.ms_inventario.service.ArticuloService;

@RestController
@RequestMapping("/api/v1/inventario")
@RequiredArgsConstructor
public class ArticuloController {
    
    private final ArticuloService articuloService;

    @GetMapping
    public ResponseEntity<List<ArticuloResponseDTO>> listar() {
        List<ArticuloResponseDTO> articulos = articuloService.findAll();
        if (articulos.isEmpty()) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(articulos);
    }

    @GetMapping("/{id}")
    public ResponseEntity<ArticuloResponseDTO> buscar(@PathVariable Integer id) {
        return ResponseEntity.ok(articuloService.findById(id));
    }

    @GetMapping("/categoria/{categoria}")
    public ResponseEntity<List<ArticuloResponseDTO>> buscarPorCategoria(@PathVariable String categoria) {
        List<ArticuloResponseDTO> articulos = articuloService.findByCategoria(categoria);
        if (articulos.isEmpty()) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(articulos);
    }

    @GetMapping("/alertas/bajo-stock")
    public ResponseEntity<List<ArticuloResponseDTO>> obtenerAlertasBajoStock() {
        List<ArticuloResponseDTO> articulos = articuloService.obtenerArticulosBajoStock();
        if (articulos.isEmpty()) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(articulos);
    }

    @PostMapping
    public ResponseEntity<ArticuloResponseDTO> guardar(@Valid @RequestBody ArticuloRequestDTO dto) {
        return ResponseEntity.status(HttpStatus.CREATED).body(articuloService.save(dto));
    }

    @PutMapping("/{id}")
    public ResponseEntity<ArticuloResponseDTO> actualizar(@PathVariable Integer id, @Valid @RequestBody ArticuloRequestDTO dto) {
        return ResponseEntity.ok(articuloService.update(id, dto));
    }

    // Endpoint rápido para sumar o restar stock (Ej: entra un camión de insumos o se usan jeringas)
    @PatchMapping("/{id}/stock")
    public ResponseEntity<ArticuloResponseDTO> ajustarStock(
            @PathVariable Integer id, 
            @RequestParam Integer cantidad, 
            @RequestParam boolean esIngreso) {
        return ResponseEntity.ok(articuloService.actualizarStock(id, cantidad, esIngreso));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Integer id) {
        articuloService.delete(id);
        return ResponseEntity.noContent().build();
    }
}