package com.hospital_vm.cl.ms_inventario.dto.response;

import java.time.LocalDate;
import lombok.Data;

@Data
public class ArticuloResponseDTO {
    private Integer id;
    private String nombre;
    private String categoria;
    private Integer stockDisponible;
    private Integer stockMinimo;
    private LocalDate fechaVencimiento;
    private String ubicacion;
}