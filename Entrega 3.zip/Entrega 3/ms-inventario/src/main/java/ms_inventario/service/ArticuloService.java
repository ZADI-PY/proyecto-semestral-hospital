package com.hospital_vm.cl.ms_inventario.service;

import java.util.List;
import com.hospital_vm.cl.ms_inventario.dto.request.ArticuloRequestDTO;
import com.hospital_vm.cl.ms_inventario.dto.response.ArticuloResponseDTO;

public interface ArticuloService {
    List<ArticuloResponseDTO> findAll();
    ArticuloResponseDTO findById(Integer id);
    List<ArticuloResponseDTO> findByCategoria(String categoria);
    List<ArticuloResponseDTO> obtenerArticulosBajoStock();
    ArticuloResponseDTO save(ArticuloRequestDTO dto);
    ArticuloResponseDTO update(Integer id, ArticuloRequestDTO dto);
    void delete(Integer id);
    ArticuloResponseDTO actualizarStock(Integer id, Integer cantidad, boolean esIngreso);
}