package com.hospital_vm.cl.ms_inventario.service.impl;

import java.util.List;
import java.util.stream.Collectors;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.hospital_vm.cl.ms_inventario.dto.request.ArticuloRequestDTO;
import com.hospital_vm.cl.ms_inventario.dto.response.ArticuloResponseDTO;
import com.hospital_vm.cl.ms_inventario.exception.ArticuloNoEncontradoException;
import com.hospital_vm.cl.ms_inventario.model.entity.Articulo;
import com.hospital_vm.cl.ms_inventario.repository.ArticuloRepository;
import com.hospital_vm.cl.ms_inventario.service.ArticuloService;
import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class ArticuloServiceImpl implements ArticuloService {
    private final ArticuloRepository articuloRepository;

    @Override
    @Transactional(readOnly = true)
    public List<ArticuloResponseDTO> findAll() {
        return articuloRepository.findAll().stream().map(this::mapearAResponseDTO).collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public ArticuloResponseDTO findById(Integer id) {
        Articulo articulo = articuloRepository.findById(id)
                .orElseThrow(() -> new ArticuloNoEncontradoException("Artículo no encontrado con ID: " + id));
        return mapearAResponseDTO(articulo);
    }

    @Override
    @Transactional(readOnly = true)
    public List<ArticuloResponseDTO> findByCategoria(String categoria) {
        return articuloRepository.findByCategoria(categoria).stream().map(this::mapearAResponseDTO).collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public List<ArticuloResponseDTO> obtenerArticulosBajoStock() {
        return articuloRepository.findArticulosConBajoStock().stream().map(this::mapearAResponseDTO).collect(Collectors.toList());
    }

    @Override
    @Transactional
    public ArticuloResponseDTO save(ArticuloRequestDTO dto) {
        Articulo nuevoArticulo = Articulo.builder()
                .nombre(dto.getNombre())
                .categoria(dto.getCategoria())
                .stockDisponible(dto.getStockDisponible())
                .stockMinimo(dto.getStockMinimo())
                .fechaVencimiento(dto.getFechaVencimiento())
                .ubicacion(dto.getUbicacion())
                .build();
        return mapearAResponseDTO(articuloRepository.save(nuevoArticulo));
    }

    @Override
    @Transactional
    public ArticuloResponseDTO update(Integer id, ArticuloRequestDTO dto) {
        Articulo articuloExistente = articuloRepository.findById(id)
                .orElseThrow(() -> new ArticuloNoEncontradoException("Artículo no encontrado con ID: " + id));

        articuloExistente.setNombre(dto.getNombre());
        articuloExistente.setCategoria(dto.getCategoria());
        articuloExistente.setStockDisponible(dto.getStockDisponible());
        articuloExistente.setStockMinimo(dto.getStockMinimo());
        articuloExistente.setFechaVencimiento(dto.getFechaVencimiento());
        articuloExistente.setUbicacion(dto.getUbicacion());

        return mapearAResponseDTO(articuloRepository.save(articuloExistente));
    }

    @Override
    @Transactional
    public void delete(Integer id) {
        Articulo articulo = articuloRepository.findById(id)
                .orElseThrow(() -> new ArticuloNoEncontradoException("Artículo no encontrado con ID: " + id));
        articuloRepository.delete(articulo);
    }

    @Override
    @Transactional
    public ArticuloResponseDTO actualizarStock(Integer id, Integer cantidad, boolean esIngreso) {
        Articulo articulo = articuloRepository.findById(id)
                .orElseThrow(() -> new ArticuloNoEncontradoException("Artículo no encontrado con ID: " + id));
        
        if (esIngreso) {
            articulo.setStockDisponible(articulo.getStockDisponible() + cantidad);
        } else {
            // Validamos que no queden saldos negativos al restar
            int nuevoStock = articulo.getStockDisponible() - cantidad;
            articulo.setStockDisponible(Math.max(nuevoStock, 0));
        }
        
        return mapearAResponseDTO(articuloRepository.save(articulo));
    }

    private ArticuloResponseDTO mapearAResponseDTO(Articulo articulo) {
        ArticuloResponseDTO dto = new ArticuloResponseDTO();
        dto.setId(articulo.getId());
        dto.setNombre(articulo.getNombre());
        dto.setCategoria(articulo.getCategoria());
        dto.setStockDisponible(articulo.getStockDisponible());
        dto.setStockMinimo(articulo.getStockMinimo());
        dto.setFechaVencimiento(articulo.getFechaVencimiento());
        dto.setUbicacion(articulo.getUbicacion());
        return dto;
    }
}