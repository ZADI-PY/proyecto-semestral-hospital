package com.hospital_vm.cl.ms_agendamiento.exception;

public class AgendamientoNoEncontradoException extends RuntimeException {
    public AgendamientoNoEncontradoException(String message) {
        super(message);
    }
}