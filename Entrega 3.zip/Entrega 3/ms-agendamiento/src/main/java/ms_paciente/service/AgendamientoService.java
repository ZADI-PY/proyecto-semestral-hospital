package com.hospital_vm.cl.ms_agendamiento.service;

import java.util.List;
import com.hospital_vm.cl.ms_agendamiento.dto.request.AgendamientoRequestDTO;
import com.hospital_vm.cl.ms_agendamiento.dto.response.AgendamientoResponseDTO;

public interface AgendamientoService {
    AgendamientoResponseDTO agendarHora(AgendamientoRequestDTO dto);
    List<AgendamientoResponseDTO> verAgendaMedico(String runMedico);
    List<AgendamientoResponseDTO> verHorasPaciente(String runPaciente);
    List<AgendamientoResponseDTO> findAll();
    AgendamientoResponseDTO findById(Integer id);
}