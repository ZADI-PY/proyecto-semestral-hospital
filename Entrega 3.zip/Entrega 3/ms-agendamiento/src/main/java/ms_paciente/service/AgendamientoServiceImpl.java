package com.hospital_vm.cl.ms_agendamiento.service.impl;

import java.util.List;
import java.util.stream.Collectors;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.hospital_vm.cl.ms_agendamiento.dto.request.AgendamientoRequestDTO;
import com.hospital_vm.cl.ms_agendamiento.dto.response.AgendamientoResponseDTO;
import com.hospital_vm.cl.ms_agendamiento.exception.AgendamientoNoEncontradoException;
import com.hospital_vm.cl.ms_agendamiento.model.entity.Agendamiento;
import com.hospital_vm.cl.ms_agendamiento.repository.AgendamientoRepository;
import com.hospital_vm.cl.ms_agendamiento.service.AgendamientoService;
import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class AgendamientoServiceImpl implements AgendamientoService {
    private final AgendamientoRepository agendamientoRepository;

    @Override
    @Transactional
    public AgendamientoResponseDTO agendarHora(AgendamientoRequestDTO dto) {
        Agendamiento nuevoAgendamiento = Agendamiento.builder()
                .runPaciente(dto.getRunPaciente())
                .runMedico(dto.getRunMedico())
                .tipoConsulta(dto.getTipoConsulta())
                .boxAtencion(dto.getBoxAtencion())
                .fechaHora(dto.getFechaHora())
                .build();
        return mapearAResponseDTO(agendamientoRepository.save(nuevoAgendamiento));
    }

    @Override
    @Transactional(readOnly = true)
    public List<AgendamientoResponseDTO> verAgendaMedico(String runMedico) {
        return agendamientoRepository.findByRunMedico(runMedico).stream()
                .map(this::mapearAResponseDTO).collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public List<AgendamientoResponseDTO> verHorasPaciente(String runPaciente) {
        return agendamientoRepository.findByRunPaciente(runPaciente).stream()
                .map(this::mapearAResponseDTO).collect(Collectors.toList());
    }
    
    @Override
    @Transactional(readOnly = true)
    public List<AgendamientoResponseDTO> findAll() {
        return agendamientoRepository.findAll().stream()
                .map(this::mapearAResponseDTO).collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public AgendamientoResponseDTO findById(Integer id) {
        Agendamiento agendamiento = agendamientoRepository.findById(id)
                .orElseThrow(() -> new AgendamientoNoEncontradoException("Agendamiento no encontrado con ID: " + id));
        return mapearAResponseDTO(agendamiento);
    }

    private AgendamientoResponseDTO mapearAResponseDTO(Agendamiento agendamiento) {
        AgendamientoResponseDTO dto = new AgendamientoResponseDTO();
        dto.setId(agendamiento.getId());
        dto.setRunPaciente(agendamiento.getRunPaciente());
        dto.setRunMedico(agendamiento.getRunMedico());
        dto.setTipoConsulta(agendamiento.getTipoConsulta());
        dto.setBoxAtencion(agendamiento.getBoxAtencion());
        dto.setFechaHora(agendamiento.getFechaHora());
        return dto;
    }
}