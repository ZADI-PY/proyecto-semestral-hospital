package com.hospital_vm.cl.ms_agendamiento.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.hospital_vm.cl.ms_agendamiento.model.entity.Agendamiento;

@Repository
public interface AgendamientoRepository extends JpaRepository<Agendamiento, Integer> {
    List<Agendamiento> findByRunPaciente(String runPaciente);
    List<Agendamiento> findByRunMedico(String runMedico);
}