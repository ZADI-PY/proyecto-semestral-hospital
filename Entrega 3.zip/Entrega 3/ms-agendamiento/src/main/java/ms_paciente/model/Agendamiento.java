package com.hospital_vm.cl.ms_agendamiento.model.entity;

import java.time.LocalDateTime;
import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "agendamientos")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Agendamiento {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(nullable = false, length = 15)
    private String runPaciente;

    @Column(nullable = false, length = 15)
    private String runMedico;

    @Column(nullable = false, length = 50)
    private String tipoConsulta;

    @Column(nullable = false, length = 20)
    private String boxAtencion;

    @Column(nullable = false)
    private LocalDateTime fechaHora;
}