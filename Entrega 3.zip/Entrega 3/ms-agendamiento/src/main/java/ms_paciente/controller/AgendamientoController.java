package com.hospital_vm.cl.ms_agendamiento.controller;

import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import com.hospital_vm.cl.ms_agendamiento.dto.request.AgendamientoRequestDTO;
import com.hospital_vm.cl.ms_agendamiento.dto.response.AgendamientoResponseDTO;
import com.hospital_vm.cl.ms_agendamiento.service.AgendamientoService;

@RestController
@RequestMapping("/api/v1/agendamiento")
@RequiredArgsConstructor
public class AgendamientoController {
    
    private final AgendamientoService agendamientoService;

    @PostMapping
    public ResponseEntity<AgendamientoResponseDTO> crearAgendamiento(@Valid @RequestBody AgendamientoRequestDTO dto) {
        return ResponseEntity.status(HttpStatus.CREATED).body(agendamientoService.agendarHora(dto));
    }

    @GetMapping("/medico/{run}")
    public ResponseEntity<List<AgendamientoResponseDTO>> agendaDelMedico(@PathVariable String run) {
        List<AgendamientoResponseDTO> agenda = agendamientoService.verAgendaMedico(run);
        if (agenda.isEmpty()) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(agenda);
    }

    @GetMapping("/paciente/{run}")
    public ResponseEntity<List<AgendamientoResponseDTO>> horasDelPaciente(@PathVariable String run) {
        List<AgendamientoResponseDTO> horas = agendamientoService.verHorasPaciente(run);
        if (horas.isEmpty()) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(horas);
    }
    
    @GetMapping
    public ResponseEntity<List<AgendamientoResponseDTO>> listarTodos() {
        List<AgendamientoResponseDTO> horas = agendamientoService.findAll();
        if (horas.isEmpty()) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(horas);
    }
    
    @GetMapping("/{id}")
    public ResponseEntity<AgendamientoResponseDTO> buscarPorId(@PathVariable Integer id) {
        return ResponseEntity.ok(agendamientoService.findById(id));
    }
}