package com.hospital_vm.cl.ms_agendamiento.dto.response;

import java.time.LocalDateTime;
import lombok.Data;

@Data
public class AgendamientoResponseDTO {
    private Integer id;
    private String runPaciente;
    private String runMedico;
    private String tipoConsulta;
    private String boxAtencion;
    private LocalDateTime fechaHora;
}