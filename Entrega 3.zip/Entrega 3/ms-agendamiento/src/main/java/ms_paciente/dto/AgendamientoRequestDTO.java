package com.hospital_vm.cl.ms_agendamiento.dto.request;

import java.time.LocalDateTime;
import jakarta.validation.constraints.FutureOrPresent;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class AgendamientoRequestDTO {
    @NotBlank(message = "El RUN del paciente es obligatorio")
    private String runPaciente;

    @NotBlank(message = "El RUN del médico es obligatorio")
    private String runMedico;

    @NotBlank(message = "El tipo de consulta es obligatorio")
    private String tipoConsulta;

    @NotBlank(message = "El box de atención es obligatorio")
    private String boxAtencion;

    @NotNull(message = "La fecha y hora son obligatorias")
    @FutureOrPresent(message = "La hora agendada debe ser en el presente o futuro")
    private LocalDateTime fechaHora;
}