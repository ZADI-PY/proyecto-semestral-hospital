package com.hospital_vm.cl.ms_historial.controller;

import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import com.hospital_vm.cl.ms_historial.dto.request.HistorialRequestDTO;
import com.hospital_vm.cl.ms_historial.dto.response.HistorialResponseDTO;
import com.hospital_vm.cl.ms_historial.service.HistorialService;

@RestController
@RequestMapping("/api/v1/historiales")
@RequiredArgsConstructor
public class HistorialController {
    
    private final HistorialService historialService;

    @GetMapping
    public ResponseEntity<List<HistorialResponseDTO>> listar() {
        List<HistorialResponseDTO> historiales = historialService.findAll();
        if (historiales.isEmpty()) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(historiales);
    }

    @GetMapping("/{id}")
    public ResponseEntity<HistorialResponseDTO> buscar(@PathVariable Integer id) {
        return ResponseEntity.ok(historialService.findById(id));
    }

    @GetMapping("/paciente/{idPaciente}")
    public ResponseEntity<List<HistorialResponseDTO>> buscarPorPaciente(@PathVariable Integer idPaciente) {
        List<HistorialResponseDTO> historiales = historialService.findByIdPaciente(idPaciente);
        if (historiales.isEmpty()) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(historiales);
    }

    @PostMapping
    public ResponseEntity<HistorialResponseDTO> guardarRegistro(@Valid @RequestBody HistorialRequestDTO dto) {
        return ResponseEntity.status(HttpStatus.CREATED).body(historialService.save(dto));
    }

    @PutMapping("/{id}")
    public ResponseEntity<HistorialResponseDTO> actualizarRegistro(@PathVariable Integer id, @Valid @RequestBody HistorialRequestDTO dto) {
        return ResponseEntity.ok(historialService.update(id, dto));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminarRegistro(@PathVariable Integer id) {
        historialService.delete(id);
        return ResponseEntity.noContent().build();
    }
}