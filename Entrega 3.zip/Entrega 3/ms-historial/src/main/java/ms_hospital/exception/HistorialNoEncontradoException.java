package com.hospital_vm.cl.ms_historial.exception;

public class HistorialNoEncontradoException extends RuntimeException {
    public HistorialNoEncontradoException(String message) {
        super(message);
    }
}