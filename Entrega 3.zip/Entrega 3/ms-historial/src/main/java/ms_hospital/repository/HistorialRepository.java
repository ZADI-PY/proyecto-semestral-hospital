package com.hospital_vm.cl.ms_historial.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.hospital_vm.cl.ms_historial.model.entity.Historial;

@Repository
public interface HistorialRepository extends JpaRepository<Historial, Integer> {
    List<Historial> findByIdPacienteOrderByFechaRegistroDesc(Integer idPaciente);
    List<Historial> findByIdMedico(Integer idMedico);
}