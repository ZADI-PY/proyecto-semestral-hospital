package com.hospital_vm.cl.ms_historial.service;

import java.util.List;
import com.hospital_vm.cl.ms_historial.dto.request.HistorialRequestDTO;
import com.hospital_vm.cl.ms_historial.dto.response.HistorialResponseDTO;

public interface HistorialService {
    List<HistorialResponseDTO> findAll();
    HistorialResponseDTO findById(Integer id);
    List<HistorialResponseDTO> findByIdPaciente(Integer idPaciente);
    HistorialResponseDTO save(HistorialRequestDTO dto);
    HistorialResponseDTO update(Integer id, HistorialRequestDTO dto);
    void delete(Integer id);
}