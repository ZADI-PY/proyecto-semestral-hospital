package com.hospital_vm.cl.ms_historial.service.impl;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.hospital_vm.cl.ms_historial.dto.request.HistorialRequestDTO;
import com.hospital_vm.cl.ms_historial.dto.response.HistorialResponseDTO;
import com.hospital_vm.cl.ms_historial.exception.HistorialNoEncontradoException;
import com.hospital_vm.cl.ms_historial.model.entity.Historial;
import com.hospital_vm.cl.ms_historial.repository.HistorialRepository;
import com.hospital_vm.cl.ms_historial.service.HistorialService;
import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class HistorialServiceImpl implements HistorialService {
    private final HistorialRepository historialRepository;

    @Override
    @Transactional(readOnly = true)
    public List<HistorialResponseDTO> findAll() {
        return historialRepository.findAll().stream().map(this::mapearAResponseDTO).collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public HistorialResponseDTO findById(Integer id) {
        Historial historial = historialRepository.findById(id)
                .orElseThrow(() -> new HistorialNoEncontradoException("Registro clínico no encontrado con ID: " + id));
        return mapearAResponseDTO(historial);
    }

    @Override
    @Transactional(readOnly = true)
    public List<HistorialResponseDTO> findByIdPaciente(Integer idPaciente) {
        // Aprovechamos el método derivado para traerlos ordenados desde el más reciente
        return historialRepository.findByIdPacienteOrderByFechaRegistroDesc(idPaciente).stream()
                .map(this::mapearAResponseDTO).collect(Collectors.toList());
    }

    @Override
    @Transactional
    public HistorialResponseDTO save(HistorialRequestDTO dto) {
        Historial nuevoRegistro = Historial.builder()
                .idPaciente(dto.getIdPaciente())
                .idMedico(dto.getIdMedico())
                .fechaRegistro(LocalDateTime.now()) // Fecha exacta del momento en que se guarda
                .diagnostico(dto.getDiagnostico())
                .tratamiento(dto.getTratamiento())
                .observaciones(dto.getObservaciones())
                .build();
        return mapearAResponseDTO(historialRepository.save(nuevoRegistro));
    }

    @Override
    @Transactional
    public HistorialResponseDTO update(Integer id, HistorialRequestDTO dto) {
        Historial registroExistente = historialRepository.findById(id)
                .orElseThrow(() -> new HistorialNoEncontradoException("Registro clínico no encontrado con ID: " + id));

        registroExistente.setDiagnostico(dto.getDiagnostico());
        registroExistente.setTratamiento(dto.getTratamiento());
        registroExistente.setObservaciones(dto.getObservaciones());
        // Nota: idPaciente, idMedico y fechaRegistro no se deberían actualizar por seguridad médica.

        return mapearAResponseDTO(historialRepository.save(registroExistente));
    }

    @Override
    @Transactional
    public void delete(Integer id) {
        Historial historial = historialRepository.findById(id)
                .orElseThrow(() -> new HistorialNoEncontradoException("Registro clínico no encontrado con ID: " + id));
        historialRepository.delete(historial);
    }

    private HistorialResponseDTO mapearAResponseDTO(Historial historial) {
        HistorialResponseDTO dto = new HistorialResponseDTO();
        dto.setId(historial.getId());
        dto.setIdPaciente(historial.getIdPaciente());
        dto.setIdMedico(historial.getIdMedico());
        dto.setFechaRegistro(historial.getFechaRegistro());
        dto.setDiagnostico(historial.getDiagnostico());
        dto.setTratamiento(historial.getTratamiento());
        dto.setObservaciones(historial.getObservaciones());
        return dto;
    }
}