package com.hospital_vm.cl.ms_historial.dto.response;

import java.time.LocalDateTime;
import lombok.Data;

@Data
public class HistorialResponseDTO {
    private Integer id;
    private Integer idPaciente;
    private Integer idMedico;
    private LocalDateTime fechaRegistro;
    private String diagnostico;
    private String tratamiento;
    private String observaciones;
}