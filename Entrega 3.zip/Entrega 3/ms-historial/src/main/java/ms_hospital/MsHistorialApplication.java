package com.hospital_vm.cl.ms_historial;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

@SpringBootApplication
@EnableDiscoveryClient // Conexión al directorio telefónico Eureka
public class MsHistorialApplication {
    public static void main(String[] args) {
        SpringApplication.run(MsHistorialApplication.class, args);
    }
}