package com.hospital_vm.cl.ms_reserva.model.entity;

import java.time.LocalDateTime;
import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "reservas")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Reserva {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(nullable = false)
    private Integer idPaciente;

    @Column(nullable = false)
    private Integer idMedico;

    @Column(nullable = false)
    private LocalDateTime fechaReserva;

    @Column(nullable = false, length = 20)
    private String estado;
}