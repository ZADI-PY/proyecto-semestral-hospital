package com.hospital_vm.cl.ms_reserva.service;

import java.util.List;
import com.hospital_vm.cl.ms_reserva.dto.request.ReservaRequestDTO;
import com.hospital_vm.cl.ms_reserva.dto.response.ReservaResponseDTO;

public interface ReservaService {
    List<ReservaResponseDTO> findAll();
    ReservaResponseDTO findById(Integer id);
    List<ReservaResponseDTO> findByPaciente(Integer idPaciente);
    ReservaResponseDTO save(ReservaRequestDTO dto);
    ReservaResponseDTO update(Integer id, ReservaRequestDTO dto);
    void delete(Integer id);
    ReservaResponseDTO cambiarEstado(Integer id, String nuevoEstado);
}