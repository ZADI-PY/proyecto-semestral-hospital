package com.hospital_vm.cl.ms_reserva.dto.request;

import java.time.LocalDateTime;
import jakarta.validation.constraints.FutureOrPresent;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class ReservaRequestDTO {
    @NotNull(message = "El ID del paciente es obligatorio")
    private Integer idPaciente;

    @NotNull(message = "El ID del médico es obligatorio")
    private Integer idMedico;

    @NotNull(message = "La fecha y hora de la reserva es obligatoria")
    @FutureOrPresent(message = "La reserva debe ser en el presente o futuro")
    private LocalDateTime fechaReserva;
}