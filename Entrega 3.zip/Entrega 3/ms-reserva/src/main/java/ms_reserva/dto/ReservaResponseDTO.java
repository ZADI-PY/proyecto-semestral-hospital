package com.hospital_vm.cl.ms_reserva.dto.response;

import java.time.LocalDateTime;
import lombok.Data;

@Data
public class ReservaResponseDTO {
    private Integer id;
    private Integer idPaciente;
    private Integer idMedico;
    private LocalDateTime fechaReserva;
    private String estado;
}