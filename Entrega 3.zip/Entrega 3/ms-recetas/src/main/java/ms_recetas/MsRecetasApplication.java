package com.hospital_vm.cl.ms_recetas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

@SpringBootApplication
@EnableDiscoveryClient
public class MsRecetasApplication {
    public static void main(String[] args) {
        SpringApplication.run(MsRecetasApplication.class, args);
    }
}