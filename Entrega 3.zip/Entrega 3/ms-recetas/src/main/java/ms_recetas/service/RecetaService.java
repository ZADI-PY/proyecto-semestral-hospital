package com.hospital_vm.cl.ms_recetas.service.impl;

import java.time.LocalDate;
import java.util.List;
import java.util.stream.Collectors;

import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hospital_vm.cl.ms_recetas.dto.request.RecetaRequestDTO;
import com.hospital_vm.cl.ms_recetas.dto.response.RecetaResponseDTO;
import com.hospital_vm.cl.ms_recetas.exception.RecetaNoEncontradaException;
import com.hospital_vm.cl.ms_recetas.model.entity.Receta;
import com.hospital_vm.cl.ms_recetas.repository.RecetaRepository;
import com.hospital_vm.cl.ms_recetas.service.RecetaService;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class RecetaServiceImpl implements RecetaService {

    private final RecetaRepository recetaRepository;

    @Override
    @Transactional(readOnly = true)
    public List<RecetaResponseDTO> findAll() {
        return recetaRepository.findAll().stream().map(this::mapearAResponseDTO).collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public RecetaResponseDTO findById(Integer id) {
        Receta receta = recetaRepository.findById(id)
                .orElseThrow(() -> new RecetaNoEncontradaException("Receta no encontrada con ID: " + id));
        return mapearAResponseDTO(receta);
    }

    @Override
    @Transactional(readOnly = true)
    public List<RecetaResponseDTO> findByPaciente(Integer idPaciente) {
        return recetaRepository.findByIdPaciente(idPaciente).stream().map(this::mapearAResponseDTO).collect(Collectors.toList());
    }

    @Override
    @Transactional
    public RecetaResponseDTO save(RecetaRequestDTO dto) {
        // En el futuro, aquí usaremos OpenFeign para validar si idPaciente e idMedico existen realmente en sus microservicios.
        Receta nuevaReceta = Receta.builder()
                .idPaciente(dto.getIdPaciente())
                .idMedico(dto.getIdMedico())
                .fechaEmision(LocalDate.now()) // La fecha se asigna automáticamente al momento de crearla
                .medicamentos(dto.getMedicamentos())
                .indicaciones(dto.getIndicaciones())
                .build();

        return mapearAResponseDTO(recetaRepository.save(nuevaReceta));
    }

    @Override
    @Transactional
    public RecetaResponseDTO update(Integer id, RecetaRequestDTO dto) {
        Receta recetaExistente = recetaRepository.findById(id)
                .orElseThrow(() -> new RecetaNoEncontradaException("No se puede actualizar. Receta no encontrada con ID: " + id));

        recetaExistente.setIdPaciente(dto.getIdPaciente());
        recetaExistente.setIdMedico(dto.getIdMedico());
        recetaExistente.setMedicamentos(dto.getMedicamentos());
        recetaExistente.setIndicaciones(dto.getIndicaciones());

        return mapearAResponseDTO(recetaRepository.save(recetaExistente));
    }

    @Override
    @Transactional
    public void delete(Integer id) {
        Receta receta = recetaRepository.findById(id)
                .orElseThrow(() -> new RecetaNoEncontradaException("No se puede eliminar. Receta no encontrada con ID: " + id));
        recetaRepository.delete(receta);
    }

    private RecetaResponseDTO mapearAResponseDTO(Receta receta) {
        RecetaResponseDTO dto = new RecetaResponseDTO();
        dto.setId(receta.getId());
        dto.setIdPaciente(receta.getIdPaciente());
        dto.setIdMedico(receta.getIdMedico());
        dto.setFechaEmision(receta.getFechaEmision());
        dto.setMedicamentos(receta.getMedicamentos());
        dto.setIndicaciones(receta.getIndicaciones());
        return dto;
    }
}