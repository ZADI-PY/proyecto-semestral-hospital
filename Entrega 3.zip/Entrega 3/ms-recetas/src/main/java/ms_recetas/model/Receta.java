package com.hospital_vm.cl.ms_recetas.model.entity;

import java.time.LocalDate;
import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "recetas")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Receta {
    
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(nullable = false)
    private Integer idPaciente;

    @Column(nullable = false)
    private Integer idMedico;

    @Column(nullable = false)
    private LocalDate fechaEmision;

    @Column(nullable = false, length = 500)
    private String medicamentos;

    @Column(nullable = false, length = 1000)
    private String indicaciones;
}