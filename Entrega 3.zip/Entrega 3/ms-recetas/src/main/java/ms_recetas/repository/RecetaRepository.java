package com.hospital_vm.cl.ms_recetas.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.hospital_vm.cl.ms_recetas.model.entity.Receta;

@Repository
public interface RecetaRepository extends JpaRepository<Receta, Integer> {
    
    List<Receta> findByIdPaciente(Integer idPaciente);
    List<Receta> findByIdMedico(Integer idMedico);
}