package com.hospital_vm.cl.ms_recetas.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

import com.hospital_vm.cl.ms_recetas.dto.request.RecetaRequestDTO;
import com.hospital_vm.cl.ms_recetas.dto.response.RecetaResponseDTO;
import com.hospital_vm.cl.ms_recetas.service.RecetaService;

@RestController
@RequestMapping("/api/v1/recetas")
@RequiredArgsConstructor
public class RecetaController {

    private final RecetaService recetaService;

    @GetMapping
    public ResponseEntity<List<RecetaResponseDTO>> listar() {
        List<RecetaResponseDTO> recetas = recetaService.findAll();
        if (recetas.isEmpty()) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(recetas);
    }

    @GetMapping("/{id}")
    public ResponseEntity<RecetaResponseDTO> buscar(@PathVariable Integer id) {
        return ResponseEntity.ok(recetaService.findById(id));
    }

    // Endpoint extra para buscar el historial de un paciente
    @GetMapping("/paciente/{idPaciente}")
    public ResponseEntity<List<RecetaResponseDTO>> buscarPorPaciente(@PathVariable Integer idPaciente) {
        List<RecetaResponseDTO> recetas = recetaService.findByPaciente(idPaciente);
        if (recetas.isEmpty()) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(recetas);
    }

    @PostMapping
    public ResponseEntity<RecetaResponseDTO> guardar(@Valid @RequestBody RecetaRequestDTO dto) {
        return ResponseEntity.status(HttpStatus.CREATED).body(recetaService.save(dto));
    }

    @PutMapping("/{id}")
    public ResponseEntity<RecetaResponseDTO> actualizar(@PathVariable Integer id, @Valid @RequestBody RecetaRequestDTO dto) {
        return ResponseEntity.ok(recetaService.update(id, dto));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Integer id) {
        recetaService.delete(id);
        return ResponseEntity.noContent().build();
    }
}