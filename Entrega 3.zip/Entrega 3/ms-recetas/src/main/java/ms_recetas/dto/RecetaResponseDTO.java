package com.hospital_vm.cl.ms_recetas.dto.request;

import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class RecetaRequestDTO {

    @NotNull(message = "El ID del paciente es obligatorio")
    private Integer idPaciente;

    @NotNull(message = "El ID del médico es obligatorio")
    private Integer idMedico;

    @NotBlank(message = "Debe especificar los medicamentos")
    private String medicamentos;

    @NotBlank(message = "Debe especificar las indicaciones")
    private String indicaciones;
}