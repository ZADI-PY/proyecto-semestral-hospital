package com.hospital_vm.cl.ms_recetas.exception;

import java.time.LocalDateTime;
import java.util.HashMap;
import java.util.Map;

import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;

// Asegúrate de importar el DTO de respuesta de errores de ms-recetas
import com.hospital_vm.cl.ms_recetas.dto.response.ApiErrorResponseDTO;

@RestControllerAdvice
public class GlobalExceptionHandler {

    private static final Logger logger = LoggerFactory.getLogger(GlobalExceptionHandler.class);

    // 1. Manejo de Errores de Validación (@Valid en el RecetaRequestDTO)
    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ApiErrorResponseDTO> manejarValidaciones(MethodArgumentNotValidException ex) {
        Map<String, String> errores = new HashMap<>();
        
        for (FieldError error : ex.getBindingResult().getFieldErrors()) {
            errores.put(error.getField(), error.getDefaultMessage());
        }
        
        logger.warn("Se detectaron {} errores de validación en la petición de recetas", errores.size());
        
        ApiErrorResponseDTO errorResponse = ApiErrorResponseDTO.builder()
                .timestamp(LocalDateTime.now())
                .status(HttpStatus.BAD_REQUEST.value())
                .error(HttpStatus.BAD_REQUEST.getReasonPhrase())
                .message("Errores de validación en los campos enviados")
                .detalles(errores)
                .build();
                
        return ResponseEntity.status(HttpStatus.BAD_REQUEST).body(errorResponse);
    }

    // 2. Manejo de Receta No Encontrada (Excepción específica de este MS)
    @ExceptionHandler(RecetaNoEncontradaException.class)
    public ResponseEntity<ApiErrorResponseDTO> manejarRecetaNoEncontrada(RecetaNoEncontradaException ex) {
        logger.warn("Recurso no encontrado: {}", ex.getMessage());
        
        ApiErrorResponseDTO errorResponse = ApiErrorResponseDTO.builder()
                .timestamp(LocalDateTime.now())
                .status(HttpStatus.NOT_FOUND.value())
                .error(HttpStatus.NOT_FOUND.getReasonPhrase())
                .message(ex.getMessage())
                .build();
                
        return ResponseEntity.status(HttpStatus.NOT_FOUND).body(errorResponse);
    }

    // 3. Manejo de Conflictos en Base de Datos
    @ExceptionHandler(DataIntegrityViolationException.class)
    public ResponseEntity<ApiErrorResponseDTO> manejarConflictosBD(DataIntegrityViolationException ex) {
        logger.error("Conflicto de integridad en la base de datos de recetas: {}", ex.getMessage());
        
        ApiErrorResponseDTO errorResponse = ApiErrorResponseDTO.builder()
                .timestamp(LocalDateTime.now())
                .status(HttpStatus.CONFLICT.value())
                .error(HttpStatus.CONFLICT.getReasonPhrase())
                .message("El registro entra en conflicto con un dato ya existente en la base de datos.")
                .build();
                
        return ResponseEntity.status(HttpStatus.CONFLICT).body(errorResponse);
    }

    // 4. Manejo de Errores Inesperados (Escudo final)
    @ExceptionHandler(Exception.class)
    public ResponseEntity<ApiErrorResponseDTO> manejarErroresInesperados(Exception ex) {
        logger.error("Error crítico e inesperado en el servidor ms-recetas", ex); 
        
        ApiErrorResponseDTO errorResponse = ApiErrorResponseDTO.builder()
                .timestamp(LocalDateTime.now())
                .status(HttpStatus.INTERNAL_SERVER_ERROR.value())
                .error(HttpStatus.INTERNAL_SERVER_ERROR.getReasonPhrase())
                .message("Ocurrió un error interno en el servidor. Por favor, intente más tarde.")
                .build();
                
        return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).body(errorResponse);
    }
}