package com.hospital_vm.cl.ms_facturacion.service.impl;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.hospital_vm.cl.ms_facturacion.dto.request.FacturaRequestDTO;
import com.hospital_vm.cl.ms_facturacion.dto.response.FacturaResponseDTO;
import com.hospital_vm.cl.ms_facturacion.exception.FacturaNoEncontradaException;
import com.hospital_vm.cl.ms_facturacion.model.entity.Factura;
import com.hospital_vm.cl.ms_facturacion.repository.FacturaRepository;
import com.hospital_vm.cl.ms_facturacion.service.FacturaService;
import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class FacturaServiceImpl implements FacturaService {
    private final FacturaRepository facturaRepository;

    @Override
    @Transactional(readOnly = true)
    public List<FacturaResponseDTO> findAll() {
        return facturaRepository.findAll().stream().map(this::mapearAResponseDTO).collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public FacturaResponseDTO findById(Integer id) {
        Factura factura = facturaRepository.findById(id)
                .orElseThrow(() -> new FacturaNoEncontradaException("Factura no encontrada con ID: " + id));
        return mapearAResponseDTO(factura);
    }

    @Override
    @Transactional(readOnly = true)
    public List<FacturaResponseDTO> findByIdPaciente(Integer idPaciente) {
        return facturaRepository.findByIdPaciente(idPaciente).stream().map(this::mapearAResponseDTO).collect(Collectors.toList());
    }

    @Override
    @Transactional
    public FacturaResponseDTO save(FacturaRequestDTO dto) {
        Factura nuevaFactura = Factura.builder()
                .idPaciente(dto.getIdPaciente())
                .fechaEmision(LocalDateTime.now())
                .montoTotal(dto.getMontoTotal())
                .descripcion(dto.getDescripcion())
                .estado("PENDIENTE") // Al crearse, nace como pendiente de pago
                .build();
        return mapearAResponseDTO(facturaRepository.save(nuevaFactura));
    }

    @Override
    @Transactional
    public FacturaResponseDTO cambiarEstado(Integer id, String estado) {
        Factura factura = facturaRepository.findById(id)
                .orElseThrow(() -> new FacturaNoEncontradaException("Factura no encontrada con ID: " + id));
        factura.setEstado(estado);
        return mapearAResponseDTO(facturaRepository.save(factura));
    }

    private FacturaResponseDTO mapearAResponseDTO(Factura factura) {
        FacturaResponseDTO dto = new FacturaResponseDTO();
        dto.setId(factura.getId());
        dto.setIdPaciente(factura.getIdPaciente());
        dto.setFechaEmision(factura.getFechaEmision());
        dto.setMontoTotal(factura.getMontoTotal());
        dto.setEstado(factura.getEstado());
        dto.setDescripcion(factura.getDescripcion());
        return dto;
    }
}