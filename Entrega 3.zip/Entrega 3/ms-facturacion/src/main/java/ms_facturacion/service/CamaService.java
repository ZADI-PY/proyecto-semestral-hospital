package com.hospital_vm.cl.ms_facturacion.service;

import java.util.List;
import com.hospital_vm.cl.ms_facturacion.dto.request.FacturaRequestDTO;
import com.hospital_vm.cl.ms_facturacion.dto.response.FacturaResponseDTO;

public interface FacturaService {
    List<FacturaResponseDTO> findAll();
    FacturaResponseDTO findById(Integer id);
    List<FacturaResponseDTO> findByIdPaciente(Integer idPaciente);
    FacturaResponseDTO save(FacturaRequestDTO dto);
    FacturaResponseDTO cambiarEstado(Integer id, String estado);
}