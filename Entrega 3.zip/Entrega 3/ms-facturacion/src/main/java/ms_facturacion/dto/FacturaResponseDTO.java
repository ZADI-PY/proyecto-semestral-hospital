package com.hospital_vm.cl.ms_facturacion.dto.response;

import java.math.BigDecimal;
import java.time.LocalDateTime;
import lombok.Data;

@Data
public class FacturaResponseDTO {
    private Integer id;
    private Integer idPaciente;
    private LocalDateTime fechaEmision;
    private BigDecimal montoTotal;
    private String estado;
    private String descripcion;
}
