package com.hospital_vm.cl.ms_facturacion.controller;

import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import com.hospital_vm.cl.ms_facturacion.dto.request.FacturaRequestDTO;
import com.hospital_vm.cl.ms_facturacion.dto.response.FacturaResponseDTO;
import com.hospital_vm.cl.ms_facturacion.service.FacturaService;

@RestController
@RequestMapping("/api/v1/facturas")
@RequiredArgsConstructor
public class FacturaController {
    
    private final FacturaService facturaService;

    @GetMapping
    public ResponseEntity<List<FacturaResponseDTO>> listar() {
        List<FacturaResponseDTO> facturas = facturaService.findAll();
        if (facturas.isEmpty()) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(facturas);
    }

    @GetMapping("/{id}")
    public ResponseEntity<FacturaResponseDTO> buscar(@PathVariable Integer id) {
        return ResponseEntity.ok(facturaService.findById(id));
    }

    @GetMapping("/paciente/{idPaciente}")
    public ResponseEntity<List<FacturaResponseDTO>> buscarPorPaciente(@PathVariable Integer idPaciente) {
        List<FacturaResponseDTO> facturas = facturaService.findByIdPaciente(idPaciente);
        if (facturas.isEmpty()) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(facturas);
    }

    @PostMapping
    public ResponseEntity<FacturaResponseDTO> emitirFactura(@Valid @RequestBody FacturaRequestDTO dto) {
        return ResponseEntity.status(HttpStatus.CREATED).body(facturaService.save(dto));
    }

    @PatchMapping("/{id}/estado")
    public ResponseEntity<FacturaResponseDTO> cambiarEstado(@PathVariable Integer id, @RequestParam String estado) {
        return ResponseEntity.ok(facturaService.cambiarEstado(id, estado));
    }
}