package com.hospital_vm.cl.ms_facturacion.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.hospital_vm.cl.ms_facturacion.model.entity.Factura;

@Repository
public interface FacturaRepository extends JpaRepository<Factura, Integer> {
    List<Factura> findByIdPaciente(Integer idPaciente);
    List<Factura> findByEstado(String estado);
}