package com.hospital_vm.cl.ms_facturacion.exception;

public class FacturaNoEncontradaException extends RuntimeException {
    public FacturaNoEncontradaException(String message) {
        super(message);
    }
}