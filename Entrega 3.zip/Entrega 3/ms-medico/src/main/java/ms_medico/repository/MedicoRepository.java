package com.hospital_vm.cl.ms_medico.repository;

import java.util.List;
import java.util.Optional;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.hospital_vm.cl.ms_medico.model.entity.Medico;

@Repository
public interface MedicoRepository extends JpaRepository<Medico, Integer> {
    boolean existsByRun(String run);
    boolean existsByCorreo(String correo);
    Optional<Medico> findByRun(String run);
    List<Medico> findByEspecialidad(String especialidad);
}