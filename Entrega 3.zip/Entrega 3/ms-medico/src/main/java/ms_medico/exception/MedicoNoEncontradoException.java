package com.hospital_vm.cl.ms_medico.exception;

public class MedicoNoEncontradoException extends RuntimeException {
    public MedicoNoEncontradoException(String message) {
        super(message);
    }
}