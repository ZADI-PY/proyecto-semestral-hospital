package com.hospital_vm.cl.ms_medico;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

@SpringBootApplication
@EnableDiscoveryClient // Listo para reportarse al directorio telefónico
public class MsMedicoApplication {
    public static void main(String[] args) {
        SpringApplication.run(MsMedicoApplication.class, args);
    }
}