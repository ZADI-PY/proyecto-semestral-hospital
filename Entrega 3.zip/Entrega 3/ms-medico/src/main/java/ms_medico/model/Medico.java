package com.hospital_vm.cl.ms_medico.model.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "medicos")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Medico {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(unique = true, length = 15, nullable = false)
    private String run;

    @Column(nullable = false, length = 100)
    private String nombres;

    @Column(nullable = false, length = 100)
    private String apellidos;

    @Column(nullable = false, length = 100)
    private String especialidad; // Ej: CARDIOLOGIA, PEDIATRIA, CIRUGIA_GENERAL

    @Column(unique = true, nullable = false, length = 100)
    private String correo;
}