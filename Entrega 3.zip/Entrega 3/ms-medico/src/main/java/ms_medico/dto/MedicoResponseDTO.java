package com.hospital_vm.cl.ms_medico.dto.response;

import lombok.Data;

@Data
public class MedicoResponseDTO {
    private Integer id;
    private String run;
    private String nombres;
    private String apellidos;
    private String especialidad;
    private String correo;
}