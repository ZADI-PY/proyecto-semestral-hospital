package com.hospital_vm.cl.ms_medico.service;

import java.util.List;
import com.hospital_vm.cl.ms_medico.dto.request.MedicoRequestDTO;
import com.hospital_vm.cl.ms_medico.dto.response.MedicoResponseDTO;

public interface MedicoService {
    List<MedicoResponseDTO> findAll();
    MedicoResponseDTO findById(Integer id);
    MedicoResponseDTO findByRun(String run);
    List<MedicoResponseDTO> findByEspecialidad(String especialidad);
    MedicoResponseDTO save(MedicoRequestDTO dto);
    MedicoResponseDTO update(Integer id, MedicoRequestDTO dto);
    void delete(Integer id);
}