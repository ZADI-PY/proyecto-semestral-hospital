package com.hospital_vm.cl.ms_medico.service.impl;

import java.util.List;
import java.util.stream.Collectors;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.hospital_vm.cl.ms_medico.dto.request.MedicoRequestDTO;
import com.hospital_vm.cl.ms_medico.dto.response.MedicoResponseDTO;
import com.hospital_vm.cl.ms_medico.exception.MedicoNoEncontradoException;
import com.hospital_vm.cl.ms_medico.model.entity.Medico;
import com.hospital_vm.cl.ms_medico.repository.MedicoRepository;
import com.hospital_vm.cl.ms_medico.service.MedicoService;
import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class MedicoServiceImpl implements MedicoService {
    private final MedicoRepository medicoRepository;

    @Override
    @Transactional(readOnly = true)
    public List<MedicoResponseDTO> findAll() {
        return medicoRepository.findAll().stream().map(this::mapearAResponseDTO).collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public MedicoResponseDTO findById(Integer id) {
        Medico medico = medicoRepository.findById(id)
                .orElseThrow(() -> new MedicoNoEncontradoException("Médico no encontrado con ID: " + id));
        return mapearAResponseDTO(medico);
    }

    @Override
    @Transactional(readOnly = true)
    public MedicoResponseDTO findByRun(String run) {
        Medico medico = medicoRepository.findByRun(run)
                .orElseThrow(() -> new MedicoNoEncontradoException("Médico no encontrado con RUN: " + run));
        return mapearAResponseDTO(medico);
    }

    @Override
    @Transactional(readOnly = true)
    public List<MedicoResponseDTO> findByEspecialidad(String especialidad) {
        return medicoRepository.findByEspecialidad(especialidad).stream()
                .map(this::mapearAResponseDTO).collect(Collectors.toList());
    }

    @Override
    @Transactional
    public MedicoResponseDTO save(MedicoRequestDTO dto) {
        if (medicoRepository.existsByRun(dto.getRun())) {
            throw new DataIntegrityViolationException("El RUN ingresado ya pertenece a otro médico registrado.");
        }
        if (medicoRepository.existsByCorreo(dto.getCorreo())) {
            throw new DataIntegrityViolationException("El correo ingresado ya pertenece a otro médico registrado.");
        }

        Medico nuevoMedico = Medico.builder()
                .run(dto.getRun())
                .nombres(dto.getNombres())
                .apellidos(dto.getApellidos())
                .especialidad(dto.getEspecialidad())
                .correo(dto.getCorreo())
                .build();
                
        return mapearAResponseDTO(medicoRepository.save(nuevoMedico));
    }

    @Override
    @Transactional
    public MedicoResponseDTO update(Integer id, MedicoRequestDTO dto) {
        Medico medicoExistente = medicoRepository.findById(id)
                .orElseThrow(() -> new MedicoNoEncontradoException("Médico no encontrado con ID: " + id));

        if (!medicoExistente.getRun().equals(dto.getRun()) && medicoRepository.existsByRun(dto.getRun())) {
            throw new DataIntegrityViolationException("El nuevo RUN ingresado pertenece a otro médico.");
        }
        if (!medicoExistente.getCorreo().equals(dto.getCorreo()) && medicoRepository.existsByCorreo(dto.getCorreo())) {
            throw new DataIntegrityViolationException("El nuevo correo ingresado pertenece a otro médico.");
        }

        medicoExistente.setRun(dto.getRun());
        medicoExistente.setNombres(dto.getNombres());
        medicoExistente.setApellidos(dto.getApellidos());
        medicoExistente.setEspecialidad(dto.getEspecialidad());
        medicoExistente.setCorreo(dto.getCorreo());

        return mapearAResponseDTO(medicoRepository.save(medicoExistente));
    }

    @Override
    @Transactional
    public void delete(Integer id) {
        Medico medico = medicoRepository.findById(id)
                .orElseThrow(() -> new MedicoNoEncontradoException("Médico no encontrado con ID: " + id));
        medicoRepository.delete(medico);
    }

    private MedicoResponseDTO mapearAResponseDTO(Medico medico) {
        MedicoResponseDTO dto = new MedicoResponseDTO();
        dto.setId(medico.getId());
        dto.setRun(medico.getRun());
        dto.setNombres(medico.getNombres());
        dto.setApellidos(medico.getApellidos());
        dto.setEspecialidad(medico.getEspecialidad());
        dto.setCorreo(medico.getCorreo());
        return dto;
    }
}