package com.hospital_vm.cl.ms_medico.controller;

import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import com.hospital_vm.cl.ms_medico.dto.request.MedicoRequestDTO;
import com.hospital_vm.cl.ms_medico.dto.response.MedicoResponseDTO;
import com.hospital_vm.cl.ms_medico.service.MedicoService;

@RestController
@RequestMapping("/api/v1/medicos")
@RequiredArgsConstructor
public class MedicoController {
    
    private final MedicoService medicoService;

    @GetMapping
    public ResponseEntity<List<MedicoResponseDTO>> listar() {
        List<MedicoResponseDTO> medicos = medicoService.findAll();
        if (medicos.isEmpty()) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(medicos);
    }

    @GetMapping("/{id}")
    public ResponseEntity<MedicoResponseDTO> buscar(@PathVariable Integer id) {
        return ResponseEntity.ok(medicoService.findById(id));
    }

    @GetMapping("/run/{run}")
    public ResponseEntity<MedicoResponseDTO> buscarPorRun(@PathVariable String run) {
        return ResponseEntity.ok(medicoService.findByRun(run));
    }

    @GetMapping("/especialidad/{especialidad}")
    public ResponseEntity<List<MedicoResponseDTO>> buscarPorEspecialidad(@PathVariable String especialidad) {
        List<MedicoResponseDTO> medicos = medicoService.findByEspecialidad(especialidad);
        if (medicos.isEmpty()) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(medicos);
    }

    @PostMapping
    public ResponseEntity<MedicoResponseDTO> guardar(@Valid @RequestBody MedicoRequestDTO dto) {
        return ResponseEntity.status(HttpStatus.CREATED).body(medicoService.save(dto));
    }

    @PutMapping("/{id}")
    public ResponseEntity<MedicoResponseDTO> actualizar(@PathVariable Integer id, @Valid @RequestBody MedicoRequestDTO dto) {
        return ResponseEntity.ok(medicoService.update(id, dto));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Integer id) {
        medicoService.delete(id);
        return ResponseEntity.noContent().build();
    }
}