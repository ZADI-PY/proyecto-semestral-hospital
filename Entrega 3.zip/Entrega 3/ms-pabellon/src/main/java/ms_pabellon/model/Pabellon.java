package com.hospital_vm.cl.ms_pabellon.model.entity;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "pabellones")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Pabellon {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(nullable = false, unique = true, length = 50)
    private String nombre;

    @Column(nullable = false, length = 50)
    private String tipo; // Ej: CIRUGIA_MAYOR, MATERNIDAD, URGENCIA

    @Column(nullable = false, length = 20)
    private String estado; // Ej: DISPONIBLE, EN_USO, LIMPIEZA, MANTENCION

    @Column(name = "id_paciente_actual")
    private Integer idPacienteActual; // Nullable, solo tiene valor si estado es EN_USO

    @Column(name = "id_medico_encargado")
    private Integer idMedicoEncargado; // Nullable, cirujano a cargo de la operación actual
}