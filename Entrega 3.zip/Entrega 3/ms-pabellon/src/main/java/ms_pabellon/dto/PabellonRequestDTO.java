package com.hospital_vm.cl.ms_pabellon.dto.request;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class PabellonRequestDTO {
    @NotBlank(message = "El nombre o número del pabellón es obligatorio")
    private String nombre;

    @NotBlank(message = "El tipo de pabellón es obligatorio")
    private String tipo;

    private String estado; // Opcional al crear, por defecto será DISPONIBLE

    private Integer idPacienteActual;
    
    private Integer idMedicoEncargado;
}