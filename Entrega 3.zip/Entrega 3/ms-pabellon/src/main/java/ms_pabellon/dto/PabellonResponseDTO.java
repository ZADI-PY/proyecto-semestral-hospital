package com.hospital_vm.cl.ms_pabellon.dto.response;

import lombok.Data;

@Data
public class PabellonResponseDTO {
    private Integer id;
    private String nombre;
    private String tipo;
    private String estado;
    private Integer idPacienteActual;
    private Integer idMedicoEncargado;
}