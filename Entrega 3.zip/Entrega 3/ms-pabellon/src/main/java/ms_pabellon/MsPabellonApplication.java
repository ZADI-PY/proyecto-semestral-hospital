package com.hospital_vm.cl.ms_pabellon;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

@SpringBootApplication
@EnableDiscoveryClient
public class MsPabellonApplication {
    public static void main(String[] args) {
        SpringApplication.run(MsPabellonApplication.class, args);
    }
}