package com.hospital_vm.cl.ms_pabellon.exception;

public class PabellonNoEncontradoException extends RuntimeException {
    public PabellonNoEncontradoException(String message) {
        super(message);
    }
}