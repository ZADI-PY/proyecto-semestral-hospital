package com.hospital_vm.cl.ms_pabellon.service.impl;

import java.util.List;
import java.util.stream.Collectors;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.hospital_vm.cl.ms_pabellon.dto.request.PabellonRequestDTO;
import com.hospital_vm.cl.ms_pabellon.dto.response.PabellonResponseDTO;
import com.hospital_vm.cl.ms_pabellon.exception.PabellonNoEncontradoException;
import com.hospital_vm.cl.ms_pabellon.model.entity.Pabellon;
import com.hospital_vm.cl.ms_pabellon.repository.PabellonRepository;
import com.hospital_vm.cl.ms_pabellon.service.PabellonService;
import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class PabellonServiceImpl implements PabellonService {
    private final PabellonRepository pabellonRepository;

    @Override
    @Transactional(readOnly = true)
    public List<PabellonResponseDTO> findAll() {
        return pabellonRepository.findAll().stream().map(this::mapearAResponseDTO).collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public PabellonResponseDTO findById(Integer id) {
        Pabellon pabellon = pabellonRepository.findById(id)
                .orElseThrow(() -> new PabellonNoEncontradoException("Pabellón no encontrado con ID: " + id));
        return mapearAResponseDTO(pabellon);
    }

    @Override
    @Transactional(readOnly = true)
    public List<PabellonResponseDTO> findByEstado(String estado) {
        return pabellonRepository.findByEstado(estado).stream().map(this::mapearAResponseDTO).collect(Collectors.toList());
    }
    
    @Override
    @Transactional(readOnly = true)
    public List<PabellonResponseDTO> findByTipo(String tipo) {
        return pabellonRepository.findByTipo(tipo).stream().map(this::mapearAResponseDTO).collect(Collectors.toList());
    }

    @Override
    @Transactional
    public PabellonResponseDTO save(PabellonRequestDTO dto) {
        if (pabellonRepository.existsByNombre(dto.getNombre())) {
            throw new DataIntegrityViolationException("Ya existe un pabellón con el nombre: " + dto.getNombre());
        }
        
        Pabellon nuevoPabellon = Pabellon.builder()
                .nombre(dto.getNombre())
                .tipo(dto.getTipo())
                .estado(dto.getEstado() != null && !dto.getEstado().isEmpty() ? dto.getEstado() : "DISPONIBLE")
                .idPacienteActual(dto.getIdPacienteActual())
                .idMedicoEncargado(dto.getIdMedicoEncargado())
                .build();
                
        return mapearAResponseDTO(pabellonRepository.save(nuevoPabellon));
    }

    @Override
    @Transactional
    public PabellonResponseDTO update(Integer id, PabellonRequestDTO dto) {
        Pabellon pabellonExistente = pabellonRepository.findById(id)
                .orElseThrow(() -> new PabellonNoEncontradoException("Pabellón no encontrado con ID: " + id));

        pabellonExistente.setNombre(dto.getNombre());
        pabellonExistente.setTipo(dto.getTipo());
        pabellonExistente.setEstado(dto.getEstado());
        pabellonExistente.setIdPacienteActual(dto.getIdPacienteActual());
        pabellonExistente.setIdMedicoEncargado(dto.getIdMedicoEncargado());

        return mapearAResponseDTO(pabellonRepository.save(pabellonExistente));
    }

    @Override
    @Transactional
    public void delete(Integer id) {
        Pabellon pabellon = pabellonRepository.findById(id)
                .orElseThrow(() -> new PabellonNoEncontradoException("Pabellón no encontrado con ID: " + id));
        pabellonRepository.delete(pabellon);
    }

    @Override
    @Transactional
    public PabellonResponseDTO actualizarEstado(Integer id, String estado, Integer idPaciente, Integer idMedico) {
        Pabellon pabellon = pabellonRepository.findById(id)
                .orElseThrow(() -> new PabellonNoEncontradoException("Pabellón no encontrado con ID: " + id));
                
        pabellon.setEstado(estado);
        // Si el estado es DISPONIBLE, LIMPIEZA o MANTENCION, limpiamos los IDs de paciente y médico
        if (!"EN_USO".equalsIgnoreCase(estado)) {
            pabellon.setIdPacienteActual(null);
            pabellon.setIdMedicoEncargado(null);
        } else {
            pabellon.setIdPacienteActual(idPaciente);
            pabellon.setIdMedicoEncargado(idMedico);
        }
        
        return mapearAResponseDTO(pabellonRepository.save(pabellon));
    }

    private PabellonResponseDTO mapearAResponseDTO(Pabellon pabellon) {
        PabellonResponseDTO dto = new PabellonResponseDTO();
        dto.setId(pabellon.getId());
        dto.setNombre(pabellon.getNombre());
        dto.setTipo(pabellon.getTipo());
        dto.setEstado(pabellon.getEstado());
        dto.setIdPacienteActual(pabellon.getIdPacienteActual());
        dto.setIdMedicoEncargado(pabellon.getIdMedicoEncargado());
        return dto;
    }
}