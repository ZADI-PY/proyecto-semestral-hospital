package com.hospital_vm.cl.ms_pabellon.controller;

import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import com.hospital_vm.cl.ms_pabellon.dto.request.PabellonRequestDTO;
import com.hospital_vm.cl.ms_pabellon.dto.response.PabellonResponseDTO;
import com.hospital_vm.cl.ms_pabellon.service.PabellonService;

@RestController
@RequestMapping("/api/v1/pabellones")
@RequiredArgsConstructor
public class PabellonController {
    
    private final PabellonService pabellonService;

    @GetMapping
    public ResponseEntity<List<PabellonResponseDTO>> listar() {
        List<PabellonResponseDTO> pabellones = pabellonService.findAll();
        if (pabellones.isEmpty()) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(pabellones);
    }

    @GetMapping("/{id}")
    public ResponseEntity<PabellonResponseDTO> buscar(@PathVariable Integer id) {
        return ResponseEntity.ok(pabellonService.findById(id));
    }

    @GetMapping("/estado/{estado}")
    public ResponseEntity<List<PabellonResponseDTO>> buscarPorEstado(@PathVariable String estado) {
        List<PabellonResponseDTO> pabellones = pabellonService.findByEstado(estado);
        if (pabellones.isEmpty()) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(pabellones);
    }
    
    @GetMapping("/tipo/{tipo}")
    public ResponseEntity<List<PabellonResponseDTO>> buscarPorTipo(@PathVariable String tipo) {
        List<PabellonResponseDTO> pabellones = pabellonService.findByTipo(tipo);
        if (pabellones.isEmpty()) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(pabellones);
    }

    @PostMapping
    public ResponseEntity<PabellonResponseDTO> guardar(@Valid @RequestBody PabellonRequestDTO dto) {
        return ResponseEntity.status(HttpStatus.CREATED).body(pabellonService.save(dto));
    }

    @PutMapping("/{id}")
    public ResponseEntity<PabellonResponseDTO> actualizar(@PathVariable Integer id, @Valid @RequestBody PabellonRequestDTO dto) {
        return ResponseEntity.ok(pabellonService.update(id, dto));
    }

    // Endpoint ágil para notificar que inicia/termina una cirugía o entra en limpieza
    @PatchMapping("/{id}/estado")
    public ResponseEntity<PabellonResponseDTO> cambiarEstado(
            @PathVariable Integer id, 
            @RequestParam String estado, 
            @RequestParam(required = false) Integer idPaciente,
            @RequestParam(required = false) Integer idMedico) {
        return ResponseEntity.ok(pabellonService.actualizarEstado(id, estado, idPaciente, idMedico));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Integer id) {
        pabellonService.delete(id);
        return ResponseEntity.noContent().build();
    }
}