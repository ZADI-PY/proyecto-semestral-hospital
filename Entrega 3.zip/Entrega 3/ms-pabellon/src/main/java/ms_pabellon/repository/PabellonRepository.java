package com.hospital_vm.cl.ms_pabellon.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.hospital_vm.cl.ms_pabellon.model.entity.Pabellon;

@Repository
public interface PabellonRepository extends JpaRepository<Pabellon, Integer> {
    List<Pabellon> findByEstado(String estado);
    List<Pabellon> findByTipo(String tipo);
    boolean existsByNombre(String nombre);
}