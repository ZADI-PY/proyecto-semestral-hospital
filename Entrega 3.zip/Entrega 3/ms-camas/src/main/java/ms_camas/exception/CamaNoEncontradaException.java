package com.hospital_vm.cl.ms_camas.exception;

public class CamaNoEncontradaException extends RuntimeException {
    public CamaNoEncontradaException(String message) {
        super(message);
    }
}