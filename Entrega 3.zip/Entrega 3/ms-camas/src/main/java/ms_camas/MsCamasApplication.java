package com.hospital_vm.cl.ms_camas;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

@SpringBootApplication
@EnableDiscoveryClient // Añadimos la conexión al directorio telefónico
public class MsCamasApplication {
    public static void main(String[] args) {
        SpringApplication.run(MsCamasApplication.class, args);
    }
}