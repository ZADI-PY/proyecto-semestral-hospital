package com.hospital_vm.cl.ms_camas.model;

import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "camas")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class Cama {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;

    @Column(nullable = false, unique = true, length = 20)
    private String numeroCama;

    @Column(nullable = false, length = 50)
    private String sala;

    @Column(nullable = false, length = 20)
    private String estado; // Ej: DISPONIBLE, OCUPADA, MANTENCION

    @Column(name = "id_paciente")
    private Integer idPaciente; // Puede ser null si la cama está disponible
}