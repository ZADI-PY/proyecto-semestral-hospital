package com.hospital_vm.cl.ms_camas.dto.request;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class CamaRequestDTO {
    @NotBlank(message = "El número de cama es obligatorio")
    private String numeroCama;

    @NotBlank(message = "La sala es obligatoria")
    private String sala;

    @NotBlank(message = "El estado de la cama es obligatorio")
    private String estado;

    private Integer idPaciente; // Opcional, solo se envía si se va a ocupar
}