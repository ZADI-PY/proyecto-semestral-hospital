package com.hospital_vm.cl.ms_camas.dto.response;

import lombok.Data;

@Data
public class CamaResponseDTO {
    private Integer id;
    private String numeroCama;
    private String sala;
    private String estado;
    private Integer idPaciente;
}