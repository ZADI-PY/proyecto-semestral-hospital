package com.hospital_vm.cl.ms_camas.controller;

import java.util.List;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import com.hospital_vm.cl.ms_camas.dto.request.CamaRequestDTO;
import com.hospital_vm.cl.ms_camas.dto.response.CamaResponseDTO;
import com.hospital_vm.cl.ms_camas.service.CamaService;

@RestController
@RequestMapping("/api/v1/camas")
@RequiredArgsConstructor
public class CamaController {
    
    private final CamaService camaService;

    @GetMapping
    public ResponseEntity<List<CamaResponseDTO>> listar() {
        List<CamaResponseDTO> camas = camaService.findAll();
        if (camas.isEmpty()) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(camas);
    }

    @GetMapping("/{id}")
    public ResponseEntity<CamaResponseDTO> buscar(@PathVariable Integer id) {
        return ResponseEntity.ok(camaService.findById(id));
    }

    @GetMapping("/estado/{estado}")
    public ResponseEntity<List<CamaResponseDTO>> buscarPorEstado(@PathVariable String estado) {
        List<CamaResponseDTO> camas = camaService.findByEstado(estado);
        if (camas.isEmpty()) {
            return ResponseEntity.noContent().build();
        }
        return ResponseEntity.ok(camas);
    }

    @PostMapping
    public ResponseEntity<CamaResponseDTO> guardar(@Valid @RequestBody CamaRequestDTO dto) {
        return ResponseEntity.status(HttpStatus.CREATED).body(camaService.save(dto));
    }

    @PutMapping("/{id}")
    public ResponseEntity<CamaResponseDTO> actualizar(@PathVariable Integer id, @Valid @RequestBody CamaRequestDTO dto) {
        return ResponseEntity.ok(camaService.update(id, dto));
    }

    // Endpoint específico para ocupar/liberar camas rápidamente
    @PatchMapping("/{id}/estado")
    public ResponseEntity<CamaResponseDTO> cambiarEstado(
            @PathVariable Integer id, 
            @RequestParam String estado, 
            @RequestParam(required = false) Integer idPaciente) {
        return ResponseEntity.ok(camaService.actualizarEstado(id, estado, idPaciente));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Integer id) {
        camaService.delete(id);
        return ResponseEntity.noContent().build();
    }
}