package com.hospital_vm.cl.ms_camas.repository;

import java.util.List;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;
import com.hospital_vm.cl.ms_camas.model.entity.Cama;

@Repository
public interface CamaRepository extends JpaRepository<Cama, Integer> {
    List<Cama> findByEstado(String estado);
    List<Cama> findBySala(String sala);
    boolean existsByNumeroCama(String numeroCama);
}