package com.hospital_vm.cl.ms_camas.service;

import java.util.List;
import com.hospital_vm.cl.ms_camas.dto.request.CamaRequestDTO;
import com.hospital_vm.cl.ms_camas.dto.response.CamaResponseDTO;

public interface CamaService {
    List<CamaResponseDTO> findAll();
    CamaResponseDTO findById(Integer id);
    List<CamaResponseDTO> findByEstado(String estado);
    CamaResponseDTO save(CamaRequestDTO dto);
    CamaResponseDTO update(Integer id, CamaRequestDTO dto);
    void delete(Integer id);
    CamaResponseDTO actualizarEstado(Integer id, String estado, Integer idPaciente);
}