package com.hospital_vm.cl.ms_camas.service.impl;

import java.util.List;
import java.util.stream.Collectors;
import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import com.hospital_vm.cl.ms_camas.dto.request.CamaRequestDTO;
import com.hospital_vm.cl.ms_camas.dto.response.CamaResponseDTO;
import com.hospital_vm.cl.ms_camas.exception.CamaNoEncontradaException;
import com.hospital_vm.cl.ms_camas.model.entity.Cama;
import com.hospital_vm.cl.ms_camas.repository.CamaRepository;
import com.hospital_vm.cl.ms_camas.service.CamaService;
import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor
public class CamaServiceImpl implements CamaService {
    private final CamaRepository camaRepository;

    @Override
    @Transactional(readOnly = true)
    public List<CamaResponseDTO> findAll() {
        return camaRepository.findAll().stream().map(this::mapearAResponseDTO).collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public CamaResponseDTO findById(Integer id) {
        Cama cama = camaRepository.findById(id)
                .orElseThrow(() -> new CamaNoEncontradaException("Cama no encontrada con ID: " + id));
        return mapearAResponseDTO(cama);
    }

    @Override
    @Transactional(readOnly = true)
    public List<CamaResponseDTO> findByEstado(String estado) {
        return camaRepository.findByEstado(estado).stream().map(this::mapearAResponseDTO).collect(Collectors.toList());
    }

    @Override
    @Transactional
    public CamaResponseDTO save(CamaRequestDTO dto) {
        if (camaRepository.existsByNumeroCama(dto.getNumeroCama())) {
            throw new DataIntegrityViolationException("El número de cama ya existe.");
        }
        Cama nuevaCama = Cama.builder()
                .numeroCama(dto.getNumeroCama())
                .sala(dto.getSala())
                .estado(dto.getEstado() != null ? dto.getEstado() : "DISPONIBLE")
                .idPaciente(dto.getIdPaciente())
                .build();
        return mapearAResponseDTO(camaRepository.save(nuevaCama));
    }

    @Override
    @Transactional
    public CamaResponseDTO update(Integer id, CamaRequestDTO dto) {
        Cama camaExistente = camaRepository.findById(id)
                .orElseThrow(() -> new CamaNoEncontradaException("Cama no encontrada con ID: " + id));

        camaExistente.setNumeroCama(dto.getNumeroCama());
        camaExistente.setSala(dto.getSala());
        camaExistente.setEstado(dto.getEstado());
        camaExistente.setIdPaciente(dto.getIdPaciente());

        return mapearAResponseDTO(camaRepository.save(camaExistente));
    }

    @Override
    @Transactional
    public void delete(Integer id) {
        Cama cama = camaRepository.findById(id)
                .orElseThrow(() -> new CamaNoEncontradaException("Cama no encontrada con ID: " + id));
        camaRepository.delete(cama);
    }

    @Override
    @Transactional
    public CamaResponseDTO actualizarEstado(Integer id, String estado, Integer idPaciente) {
        Cama cama = camaRepository.findById(id)
                .orElseThrow(() -> new CamaNoEncontradaException("Cama no encontrada con ID: " + id));
        cama.setEstado(estado);
        cama.setIdPaciente(idPaciente); // Si se libera, esto debería venir en null
        return mapearAResponseDTO(camaRepository.save(cama));
    }

    private CamaResponseDTO mapearAResponseDTO(Cama cama) {
        CamaResponseDTO dto = new CamaResponseDTO();
        dto.setId(cama.getId());
        dto.setNumeroCama(cama.getNumeroCama());
        dto.setSala(cama.getSala());
        dto.setEstado(cama.getEstado());
        dto.setIdPaciente(cama.getIdPaciente());
        return dto;
    }
}