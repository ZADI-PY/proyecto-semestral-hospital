package com.hospital_vm.cl.ms_paciente;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.client.discovery.EnableDiscoveryClient;

@SpringBootApplication
@EnableDiscoveryClient // Esta es la magia que le dirá a Eureka: "¡Hola, estoy vivo y este es mi puerto!"
public class MsPacienteApplication {

    public static void main(String[] args) {
        SpringApplication.run(MsPacienteApplication.class, args);
    }
    
}