package com.hospital_vm.cl.ms_paciente.service.impl;

import java.util.List;
import java.util.stream.Collectors;

import org.springframework.dao.DataIntegrityViolationException;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.hospital_vm.cl.ms_paciente.dto.request.PacienteRequestDTO;
import com.hospital_vm.cl.ms_paciente.dto.response.PacienteResponseDTO;
import com.hospital_vm.cl.ms_paciente.exception.PacienteNoEncontradoException;
import com.hospital_vm.cl.ms_paciente.model.entity.Paciente;
import com.hospital_vm.cl.ms_paciente.repository.PacienteRepository;
import com.hospital_vm.cl.ms_paciente.service.PacienteService;

import lombok.RequiredArgsConstructor;

@Service
@RequiredArgsConstructor 
public class PacienteServiceImpl implements PacienteService {

    private final PacienteRepository pacienteRepository;

    @Override
    @Transactional(readOnly = true) 
    public List<PacienteResponseDTO> findAll() {
        return pacienteRepository.findAll().stream()
                .map(this::mapearAResponseDTO)
                .collect(Collectors.toList());
    }

    @Override
    @Transactional(readOnly = true)
    public PacienteResponseDTO findById(Integer id) {

        Paciente paciente = pacienteRepository.findById(id)
                .orElseThrow(() -> new PacienteNoEncontradoException("No se encontró paciente con el ID: " + id));
        
        return mapearAResponseDTO(paciente);
    }

    @Override
    @Transactional
    public PacienteResponseDTO save(PacienteRequestDTO dto) {
        // 1. Validacion preventiva contra la Base de Datos usando los nuevos métodos del Repositorio
        if (pacienteRepository.existsByRun(dto.getRun())) {
            throw new DataIntegrityViolationException("El RUN ingresado ya se encuentra registrado.");
        }
        if (pacienteRepository.existsByCorreo(dto.getCorreo())) {
            throw new DataIntegrityViolationException("El correo ingresado ya se encuentra registrado.");
        }

        // 2. Transformar DTO a Entidad 
        Paciente nuevoPaciente = Paciente.builder()
                .run(dto.getRun())
                .nombres(dto.getNombres())
                .apellidos(dto.getApellidos())
                .fechaNacimiento(dto.getFechaNacimiento())
                .correo(dto.getCorreo())
                .build();

        // 3. Guardar y retornar transformado
        Paciente pacienteGuardado = pacienteRepository.save(nuevoPaciente);
        return mapearAResponseDTO(pacienteGuardado);
    }

    @Override
    @Transactional
    public PacienteResponseDTO update(Integer id, PacienteRequestDTO dto) {
        // 1. Verificar existencia
        Paciente pacienteExistente = pacienteRepository.findById(id)
                .orElseThrow(() -> new PacienteNoEncontradoException("No se puede actualizar. Paciente no encontrado con ID: " + id));

        // 2. Validar que si cambia de RUN/Correo, el nuevo no pertenezca ya a OTRA persona
        if (!pacienteExistente.getRun().equals(dto.getRun()) && pacienteRepository.existsByRun(dto.getRun())) {
            throw new DataIntegrityViolationException("El nuevo RUN ingresado pertenece a otro paciente.");
        }
        if (!pacienteExistente.getCorreo().equals(dto.getCorreo()) && pacienteRepository.existsByCorreo(dto.getCorreo())) {
            throw new DataIntegrityViolationException("El nuevo correo ingresado pertenece a otro paciente.");
        }

        // 3. Actualizar la entidad rastreada por JPA
        pacienteExistente.setRun(dto.getRun());
        pacienteExistente.setNombres(dto.getNombres());
        pacienteExistente.setApellidos(dto.getApellidos());
        pacienteExistente.setFechaNacimiento(dto.getFechaNacimiento());
        pacienteExistente.setCorreo(dto.getCorreo());

        Paciente pacienteActualizado = pacienteRepository.save(pacienteExistente);
        return mapearAResponseDTO(pacienteActualizado);
    }

    @Override
    @Transactional
    public void delete(Integer id) {
        Paciente paciente = pacienteRepository.findById(id)
                .orElseThrow(() -> new PacienteNoEncontradoException("No se puede eliminar. Paciente no encontrado con ID: " + id));
        
        pacienteRepository.delete(paciente);
    }

    private PacienteResponseDTO mapearAResponseDTO(Paciente paciente) {
        PacienteResponseDTO dto = new PacienteResponseDTO();
        dto.setId(paciente.getId());
        dto.setRun(paciente.getRun());
        dto.setNombres(paciente.getNombres());
        dto.setApellidos(paciente.getApellidos());
        dto.setFechaNacimiento(paciente.getFechaNacimiento());
        dto.setCorreo(paciente.getCorreo());
        return dto;
    }
}
