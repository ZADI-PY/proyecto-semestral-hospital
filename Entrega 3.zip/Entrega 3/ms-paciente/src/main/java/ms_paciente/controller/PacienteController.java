package com.hospital_vm.cl.ms_paciente.controller;

import java.util.List;

import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.DeleteMapping;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.PutMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;

// Asegúrate de importar desde tus nuevos paquetes
import com.hospital_vm.cl.ms_paciente.dto.request.PacienteRequestDTO;
import com.hospital_vm.cl.ms_paciente.dto.response.PacienteResponseDTO;
import com.hospital_vm.cl.ms_paciente.service.PacienteService;

@RestController
@RequestMapping("/api/v1/pacientes")
@RequiredArgsConstructor // Lombok genera el constructor automáticamente para la inyeccion de dependencias
public class PacienteController {

    // Inyeccion por constructor 
    private final PacienteService pacienteService;

    @GetMapping
    public ResponseEntity<List<PacienteResponseDTO>> listar() {
        List<PacienteResponseDTO> pacientes = pacienteService.findAll();
        if (pacientes.isEmpty()) {
            return ResponseEntity.noContent().build(); // 204 No Content
        }
        return ResponseEntity.ok(pacientes); // 200 OK
    }

    @GetMapping("/{id}")
    public ResponseEntity<PacienteResponseDTO> buscar(@PathVariable Integer id) {
        //Si no existe, el servicio lanza la excepcion y el GlobalExceptionHandler devuelve el 404.
        PacienteResponseDTO paciente = pacienteService.findById(id);
        return ResponseEntity.ok(paciente); // 200 OK
    }

    @PostMapping
    public ResponseEntity<PacienteResponseDTO> guardar(@Valid @RequestBody PacienteRequestDTO dto) {
        // El servicio se encarga de transformar el RequestDTO a Entidad, guardar, y devolver el ResponseDTO.
        PacienteResponseDTO pacienteNuevo = pacienteService.save(dto);
        return ResponseEntity.status(HttpStatus.CREATED).body(pacienteNuevo); // 201 Created
    }

    @PutMapping("/{id}")
    public ResponseEntity<PacienteResponseDTO> actualizar(@PathVariable Integer id, @Valid @RequestBody PacienteRequestDTO dto) {
        // Pasamos el ID y los datos nuevos. El servicio maneja la lógica de busqueda y actualizacion.
        PacienteResponseDTO pacienteActualizado = pacienteService.update(id, dto);
        return ResponseEntity.ok(pacienteActualizado); // 200 OK
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<Void> eliminar(@PathVariable Integer id) {
    
        pacienteService.delete(id);
        return ResponseEntity.noContent().build(); // 204 No Content
    }
}