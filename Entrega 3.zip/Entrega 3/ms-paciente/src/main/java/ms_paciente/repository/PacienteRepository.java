package ms_paciente.repository;
package com.hospital_vm.cl.ms_paciente.repository;

import java.util.Optional;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

// Actualizamos el import apuntando a la nueva ubicación de la entidad
import com.hospital_vm.cl.ms_paciente.model.entity.Paciente;

@Repository
public interface PacienteRepository extends JpaRepository<Paciente, Integer> {
    /* Verifica si ya existe un paciente registrado con el mismo RUN */
    boolean existsByRun(String run);

    /*Verifica si ya existe un paciente registrado con el mismo correo */
    boolean existsByCorreo(String correo);

    Optional<Paciente> findByRun(String run);
}