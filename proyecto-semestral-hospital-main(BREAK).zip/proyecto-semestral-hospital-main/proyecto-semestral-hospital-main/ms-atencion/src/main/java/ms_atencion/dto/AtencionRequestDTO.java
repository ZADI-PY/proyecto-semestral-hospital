package ms_atencion.dto;

import jakarta.validation.constraints.NotBlank;
import java.time.LocalDateTime;

public class AtencionRequestDTO {
    @NotBlank
    private String runPaciente;
    @NotBlank
    private String runDoctor;
    private LocalDateTime fechaAtencion;
    @NotBlank
    private String diagnostico;
    private String observaciones;

    // Getters y Setters
    public String getRunPaciente() { return runPaciente; }
    public void setRunPaciente(String runPaciente) { this.runPaciente = runPaciente; }
    public String getRunDoctor() { return runDoctor; }
    public void setRunDoctor(String runDoctor) { this.runDoctor = runDoctor; }
    public LocalDateTime getFechaAtencion() { return fechaAtencion; }
    public void setFechaAtencion(LocalDateTime fechaAtencion) { this.fechaAtencion = fechaAtencion; }
    public String getDiagnostico() { return diagnostico; }
    public void setDiagnostico(String diagnostico) { this.diagnostico = diagnostico; }
    public String getObservaciones() { return observaciones; }
    public void setObservaciones(String observaciones) { this.observaciones = observaciones; }
}