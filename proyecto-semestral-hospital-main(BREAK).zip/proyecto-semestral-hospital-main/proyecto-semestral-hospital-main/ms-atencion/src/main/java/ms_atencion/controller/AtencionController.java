package ms_atencion.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import jakarta.validation.Valid;

import ms_atencion.dto.AtencionRequestDTO;
import ms_atencion.model.Atencion;
import ms_atencion.service.AtencionService;

@RestController
@RequestMapping("/api/v1/atenciones")
public class AtencionController {

    @Autowired
    private AtencionService atencionService;

    @PostMapping
    public ResponseEntity<Atencion> registrarAtencion(@Valid @RequestBody AtencionRequestDTO dto) {
        Atencion atencion = new Atencion();
        atencion.setRunPaciente(dto.getRunPaciente());
        atencion.setRunDoctor(dto.getRunDoctor());
        // Si no mandan fecha, asignamos la actual por defecto
        atencion.setFechaAtencion(dto.getFechaAtencion() != null ? dto.getFechaAtencion() : java.time.LocalDateTime.now());
        atencion.setDiagnostico(dto.getDiagnostico());
        atencion.setObservaciones(dto.getObservaciones());
        
        return ResponseEntity.status(HttpStatus.CREATED).body(atencionService.guardar(atencion));
    }

    @GetMapping
    public ResponseEntity<Iterable<Atencion>> listarTodas() {
        return ResponseEntity.ok(atencionService.listarTodas());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Atencion> buscarPorId(@PathVariable Integer id) {
        return ResponseEntity.ok(atencionService.buscarPorId(id));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> eliminar(@PathVariable Integer id) {
        atencionService.eliminar(id);
        return ResponseEntity.noContent().build();
    }
}