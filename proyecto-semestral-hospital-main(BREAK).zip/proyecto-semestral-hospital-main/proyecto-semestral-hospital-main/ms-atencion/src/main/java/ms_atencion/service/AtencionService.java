package ms_atencion.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ms_atencion.model.Atencion;
import ms_atencion.repository.AtencionRepository;

@Service
public class AtencionService {
    @Autowired
    private AtencionRepository atencionRepository;

    public Atencion guardar(Atencion atencion) {
        return atencionRepository.save(atencion);
    }

    public Iterable<Atencion> listarTodas() {
        return atencionRepository.findAll();
    }

    public Atencion buscarPorId(Integer id) {
        return atencionRepository.findById(id).orElseThrow(() -> new RuntimeException("Atención no encontrada"));
    }

    public void eliminar(Integer id) {
        atencionRepository.deleteById(id);
    }
}