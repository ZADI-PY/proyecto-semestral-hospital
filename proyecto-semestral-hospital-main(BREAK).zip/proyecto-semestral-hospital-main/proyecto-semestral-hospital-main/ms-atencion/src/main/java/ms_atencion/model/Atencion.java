package ms_atencion.model;

import jakarta.persistence.*;
import java.time.LocalDateTime;

@Entity
@Table(name = "atenciones")
public class Atencion {
    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Integer id;
    private String runPaciente;
    private String runDoctor;
    private LocalDateTime fechaAtencion;
    private String diagnostico;
    private String observaciones;

    // Getters y Setters
    public Integer getId() { return id; }
    public void setId(Integer id) { this.id = id; }
    public String getRunPaciente() { return runPaciente; }
    public void setRunPaciente(String runPaciente) { this.runPaciente = runPaciente; }
    public String getRunDoctor() { return runDoctor; }
    public void setRunDoctor(String runDoctor) { this.runDoctor = runDoctor; }
    public LocalDateTime getFechaAtencion() { return fechaAtencion; }
    public void setFechaAtencion(LocalDateTime fechaAtencion) { this.fechaAtencion = fechaAtencion; }
    public String getDiagnostico() { return diagnostico; }
    public void setDiagnostico(String diagnostico) { this.diagnostico = diagnostico; }
    public String getObservaciones() { return observaciones; }
    public void setObservaciones(String observaciones) { this.observaciones = observaciones; }
}