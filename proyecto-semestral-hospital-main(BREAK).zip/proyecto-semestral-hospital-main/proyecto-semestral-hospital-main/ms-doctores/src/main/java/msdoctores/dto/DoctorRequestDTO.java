package msdoctores.dto;

import jakarta.validation.constraints.NotBlank;

public class DoctorRequestDTO {
    @NotBlank
    private String run;
    @NotBlank
    private String nombre;
    @NotBlank
    private String especialidad;
    private String correo;

    // Getters y Setters
    public String getRun() { return run; }
    public void setRun(String run) { this.run = run; }
    public String getNombre() { return nombre; }
    public void setNombre(String nombre) { this.nombre = nombre; }
    public String getEspecialidad() { return especialidad; }
    public void setEspecialidad(String especialidad) { this.especialidad = especialidad; }
    public String getCorreo() { return correo; }
    public void setCorreo(String correo) { this.correo = correo; }
}