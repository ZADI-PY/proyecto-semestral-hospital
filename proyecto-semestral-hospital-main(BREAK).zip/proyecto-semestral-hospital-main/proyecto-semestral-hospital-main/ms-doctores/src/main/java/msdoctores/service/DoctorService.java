package msdoctores.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import ms_doctores.model.Doctor;
import ms_doctores.repository.DoctorRepository;

@Service
public class DoctorService {
    @Autowired
    private DoctorRepository doctorRepository;

    public Doctor guardar(Doctor doctor) {
        return doctorRepository.save(doctor);
    }

    public Iterable<Doctor> listarTodos() {
        return doctorRepository.findAll();
    }

    public Doctor buscarPorId(Integer id) {
        return doctorRepository.findById(id).orElseThrow(() -> new RuntimeException("Doctor no encontrado"));
    }

    public void eliminar(Integer id) {
        doctorRepository.deleteById(id);
    }
}