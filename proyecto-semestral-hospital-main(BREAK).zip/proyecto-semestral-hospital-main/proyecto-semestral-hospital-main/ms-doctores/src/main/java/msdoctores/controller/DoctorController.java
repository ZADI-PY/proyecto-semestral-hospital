package msdoctores.controller;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import jakarta.validation.Valid;

import ms_doctores.dto.DoctorRequestDTO;
import ms_doctores.model.Doctor;
import ms_doctores.service.DoctorService;

@RestController
@RequestMapping("/api/v1/doctores")
public class DoctorController {

    @Autowired
    private DoctorService doctorService;

    @PostMapping
    public ResponseEntity<Doctor> registrarDoctor(@Valid @RequestBody DoctorRequestDTO dto) {
        Doctor doctor = new Doctor();
        doctor.setRun(dto.getRun());
        doctor.setNombre(dto.getNombre());
        doctor.setEspecialidad(dto.getEspecialidad());
        doctor.setCorreo(dto.getCorreo());
        
        return ResponseEntity.status(HttpStatus.CREATED).body(doctorService.guardar(doctor));
    }

    @GetMapping
    public ResponseEntity<Iterable<Doctor>> listarTodos() {
        return ResponseEntity.ok(doctorService.listarTodos());
    }

    @GetMapping("/{id}")
    public ResponseEntity<Doctor> buscarPorId(@PathVariable Integer id) {
        return ResponseEntity.ok(doctorService.buscarPorId(id));
    }

    @DeleteMapping("/{id}")
    public ResponseEntity<?> eliminar(@PathVariable Integer id) {
        doctorService.eliminar(id);
        return ResponseEntity.noContent().build();
    }
}